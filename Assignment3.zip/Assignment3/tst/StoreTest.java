
import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import java.io.*;
import java.net.URL;
import java.util.ArrayList;

public class StoreTest {

    private static Store store;

    @Before
    public void setup() throws IOException {
        store = new Store();
    }

    @Test
    public void testDownload() throws IOException {
        Inventory inventory = store.getInventory();

        for(Game g: inventory.getGames()) {
            g.printGame();
        }
        Assert.assertEquals(4,inventory.getSize());
    }


    @Test
    public void testFindCheapestGame() {
        Assert.assertEquals("Should be Portal 2, 620, unless there is a sale or issue with the data",
                "620", store.findCheapestGame().getSteamID());
    }

    @Test
    public void testFindMostExpensiveGame() {
        Assert.assertEquals("Should be Baldur's gate 3, 1086940, unless there is a sale or issue with the data",
                "1086940", store.findMostExpensiveGame().getSteamID());
    }

    @Test
    public void testGetAveragePriceOfAllGames() {
        System.out.println(store.getAveragePriceOfAllGames());
        Assert.assertEquals("Should work unless there is an issue with the data", 3249.0, store.getAveragePriceOfAllGames(),0);
    }
}
