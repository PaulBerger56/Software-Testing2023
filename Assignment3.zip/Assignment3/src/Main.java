import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
        Store store = new Store();
        System.out.println();
        System.out.println(store.findCheapestGame().getSteamID());

    }
}

